/*
  Cole isto logo depois do <script> que já existe no seu HTML (o que
  controla as telas, o upload de arquivo e o botão de play). Ele reaproveita
  os mesmos IDs que você já tem: uploadBtn, fileInput, uploadLabel, micBtn,
  playBtn, playTooltip.
*/
(function () {
  const API_BASE = 'http://localhost:8000/api'; // troque pela URL do Django em produção

  const fileInput = document.getElementById('fileInput');
  const uploadLabel = document.getElementById('uploadLabel');
  const micBtn = document.getElementById('micBtn');
  const playBtn = document.getElementById('playBtn');
  const playTooltip = document.getElementById('playTooltip');
  const audioPlayer = document.getElementById('audioPlayer');

  let gravador;
  let pedacosDeAudio = [];
  let gravando = false;

  function mostrarCarregando(carregando) {
    uploadLabel.dataset.textoOriginal = uploadLabel.dataset.textoOriginal || uploadLabel.textContent;
    uploadLabel.textContent = carregando ? 'Decifrando...' : uploadLabel.dataset.textoOriginal;
    playBtn.style.opacity = carregando ? '0.5' : '1';
    playBtn.style.pointerEvents = carregando ? 'none' : 'auto';
  }

  function mostrarErro(mensagem) {
    playTooltip.textContent = mensagem;
    playTooltip.classList.add('show');
    setTimeout(() => playTooltip.classList.remove('show'), 2500);
  }

  function mostrarResultado(dados) {
    // dados vem de InterceptacaoSerializer:
    // { id, status, emocao_detectada, confianca, frase_traduzida, erro, criado_em }
    uploadLabel.textContent = `Humor: ${dados.emocao_detectada}`;
    uploadLabel.dataset.textoOriginal = uploadLabel.textContent;

    playTooltip.textContent = dados.frase_traduzida;
    playTooltip.classList.add('show');
    setTimeout(() => playTooltip.classList.remove('show'), 4000);

    // Quando a etapa de IA (Gemini/GPT) passar a gerar também um áudio
    // (texto-para-fala) em vez de só o texto, basta trocar esta linha por:
    //   audioPlayer.src = dados.audio_traduzido_url;
    // Por enquanto o botão de play só existe pra confirmar visualmente
    // que o resultado chegou.
  }

  async function enviarAudio(blobOuArquivo, nomeArquivo) {
    const formData = new FormData();
    formData.append('audio', blobOuArquivo, nomeArquivo || 'gravacao.webm');

    mostrarCarregando(true);
    try {
      const resposta = await fetch(`${API_BASE}/interceptacoes/`, {
        method: 'POST',
        body: formData,
      });
      const dados = await resposta.json();

      if (!resposta.ok) {
        throw new Error(dados.erro || 'Falha ao decifrar o áudio.');
      }

      mostrarResultado(dados);
    } catch (erro) {
      console.error(erro);
      mostrarErro('Erro ao contatar o servidor. Tente de novo.');
    } finally {
      mostrarCarregando(false);
    }
  }

  // Upload de arquivo (reaproveita o <input id="fileInput"> que já existe)
  fileInput.addEventListener('change', function () {
    const arquivo = fileInput.files[0];
    if (arquivo) enviarAudio(arquivo, arquivo.name);
  });

  // Gravação pelo microfone (reaproveita o botão id="micBtn")
  micBtn.addEventListener('click', async function () {
    if (!gravando) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        gravador = new MediaRecorder(stream);
        pedacosDeAudio = [];

        gravador.ondataavailable = (evento) => pedacosDeAudio.push(evento.data);
        gravador.onstop = () => {
          const blob = new Blob(pedacosDeAudio, { type: 'audio/webm' });
          enviarAudio(blob, 'gravacao.webm');
          stream.getTracks().forEach((faixa) => faixa.stop());
        };

        gravador.start();
        gravando = true;
      } catch (erro) {
        mostrarErro('Não consegui acessar o microfone.');
      }
    } else {
      gravador.stop();
      gravando = false;
    }
  });
})();
