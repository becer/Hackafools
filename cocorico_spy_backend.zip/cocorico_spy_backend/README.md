# Cocorico Spy — Backend Django

Backend que recebe os áudios do seu site (upload ou gravação pelo
microfone), manda pro modelo que roda no Google Colab, e devolve a
emoção detectada + uma frase traduzida.

## Como as peças se conectam

```
Seu HTML/CSS (já pronto)
        │  fetch() ao clicar em upload/gravar (ver frontend/integracao.js)
        ▼
Django REST API  (este projeto)
        │  translator/services/colab_client.py -> POST /predict
        ▼
Servidor no Google Colab (colab/servidor_colab.py, FastAPI + ngrok)
        │  RandomForest treinado com os .wav de cada emoção
        ▼
Resposta: {"emocao": "brava", "confianca": 0.87}
        │
        ▼
translator/services/traducao.py -> transforma a emoção em frase
        │  (hoje: dicionário fixo — depois: Gemini/GPT, mesma interface)
        ▼
Django devolve tudo pro front-end
```

## 1) Rodando o Django localmente

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env          # e ajuste os valores, principalmente COLAB_API_KEY

python manage.py migrate
python manage.py createsuperuser   # opcional, pra ver os resultados em /admin/
python manage.py runserver
```

A API sobe em `http://localhost:8000`. Endpoints:

- `POST /api/interceptacoes/` — envia um áudio (`multipart/form-data`,
  campo `audio`), devolve o resultado já processado.
- `GET /api/interceptacoes/<id>/` — consulta um resultado já salvo.
- `POST /api/colab/registrar/` — usado pelo próprio notebook do Colab
  pra avisar sua URL pública atual (veja abaixo).

## 2) Rodando o modelo no Google Colab

1. Suba seus arquivos `.wav` de treino (um ou mais por emoção) no Colab.
2. Numa célula, instale as dependências:
   ```
   !pip install fastapi uvicorn pyngrok python-multipart nest_asyncio requests
   !pip install librosa scikit-learn pydub
   ```
3. Copie o conteúdo de `colab/servidor_colab.py` pra outra célula e rode.
   Ele treina o modelo com as emoções listadas em `ARQUIVOS_DE_TREINO`,
   sobe uma API local e expõe ela publicamente via ngrok.
4. Se quiser que o Colab avise o Django sozinho sobre a URL nova a cada
   reinício, defina a variável de ambiente `DJANGO_URL` no Colab (a URL
   pública do seu Django, ex: via `os.environ['DJANGO_URL'] = '...'` numa
   célula antes de rodar o servidor). Sem isso, copie a URL impressa e
   cole em `COLAB_API_URL` no `.env`, ou cadastre manualmente em
   `/admin/translator/configuracaocolab/`.

**Importante:** `COLAB_API_KEY` no `.env` do Django e `CHAVE_SECRETA` no
script do Colab precisam ser exatamente iguais — é a autenticação simples
entre os dois.

## 3) Conectando ao seu HTML/CSS já existente

Seu HTML já tem os botões de upload, gravação e play com os IDs certos
(`uploadBtn`, `fileInput`, `micBtn`, `playBtn`...). Basta colar o conteúdo
de `frontend/integracao.js` logo depois do `<script>` que já existe na
sua página, e ajustar a constante `API_BASE` pra apontar pro seu Django.

## 4) Plugando o Gemini/GPT depois (o "tradutor com IA")

Toda a lógica de "emoção → frase" passa por
`translator/services/traducao.py`, através da interface `TradutorDeHumor`.
Pra trocar o dicionário fixo por uma chamada real de IA:

1. Implemente a chamada à API do Gemini/GPT dentro do método
   `TradutorComIA.traduzir()`.
2. No `.env`, mude `MOTOR_DE_TRADUCAO=simples` para `MOTOR_DE_TRADUCAO=ia`.

Nenhum outro arquivo do projeto precisa mudar — a view
(`InterceptacaoUploadView`) só conhece a interface, não a implementação.

## 5) Adicionando mais estados de humor

- No Colab: adicione a nova emoção (e seus `.wav` de treino) em
  `ARQUIVOS_DE_TREINO` dentro de `colab/servidor_colab.py`.
- No Django: adicione a frase correspondente no dicionário `FRASES` de
  `translator/services/traducao.py` (a chave precisa ser o mesmo texto
  usado como rótulo no treino do Colab).

## Observações sobre produção

- O processamento hoje é síncrono (o Django espera o Colab responder
  antes de devolver a resposta HTTP). Se os áudios ou o modelo ficarem
  mais pesados, vale migrar pra processamento assíncrono (Celery +
  Redis, por exemplo), usando o `GET /api/interceptacoes/<id>/` que já
  existe para o front-end fazer polling.
- Troque `DJANGO_SECRET_KEY`, `COLAB_API_KEY` e `DEBUG=False` antes de
  colocar em produção, e restrinja `CORS_ALLOWED_ORIGINS` ao domínio
  real do seu site.
