from rest_framework import serializers

from .models import Interceptacao


class InterceptacaoUploadSerializer(serializers.ModelSerializer):
    """Usado só para validar/salvar o arquivo que chega."""

    class Meta:
        model = Interceptacao
        fields = ['id', 'audio']


class InterceptacaoSerializer(serializers.ModelSerializer):
    """Usado para devolver o resultado completo pro front-end."""

    class Meta:
        model = Interceptacao
        fields = [
            'id',
            'status',
            'emocao_detectada',
            'confianca',
            'frase_traduzida',
            'erro',
            'criado_em',
        ]
