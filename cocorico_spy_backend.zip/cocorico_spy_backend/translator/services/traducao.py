"""Camada de tradução: pega a emoção que o modelo detectou e devolve uma
frase em português. Hoje é um dicionário fixo (TradutorSimples). Quando
vocês plugarem o Gemini/GPT, é só terminar a implementação de
TradutorComIA — nada mais no projeto precisa mudar, porque a view só
conhece a interface TradutorDeHumor.
"""
from abc import ABC, abstractmethod

from django.conf import settings


class TradutorDeHumor(ABC):
    @abstractmethod
    def traduzir(self, emocao: str, confianca: float | None = None) -> str:
        ...


class TradutorSimples(TradutorDeHumor):
    """Dicionário fixo — serve pra validar o fluxo ponta a ponta antes de
    plugar um LLM de verdade."""

    FRASES = {
        'brava': 'CÔ CÔ CÔ! Sai da minha área agora mesmo!',
        'calma': 'Cocoricó... hoje o milho tá bom, hein.',
        'feliz': 'CÓ-CÓ-RÓ-CÓ! Acabei de botar um ovo, gente!',
        'triste': 'Cocô... cocô... ninguém quer brincar comigo hoje.',
        'pergunta': 'Cocoricó? Cadê o resto do milho?',
        'medo': 'CÓ CÓ CÓ CÓ!! Tem alguém estranho por aqui!!',
    }

    def traduzir(self, emocao: str, confianca: float | None = None) -> str:
        return self.FRASES.get(
            emocao, f'A galinha fez um som que ainda não sei traduzir ({emocao}).'
        )


class TradutorComIA(TradutorDeHumor):
    """Ponto de extensão: aqui entra a chamada real ao Gemini ou ao GPT.
    Sugestão de prompt: mandar a emoção detectada (e talvez a confiança)
    e pedir de volta uma frase curta e engraçada "na voz" da galinha.
    """

    def traduzir(self, emocao: str, confianca: float | None = None) -> str:
        # TODO: chamar a API do Gemini/GPT aqui, por exemplo:
        #
        # resposta = cliente_ia.gerar(
        #     f'Escreva uma frase curta e engraçada que uma galinha '
        #     f'diria se estivesse se sentindo "{emocao}".'
        # )
        # return resposta.texto
        #
        # Por enquanto cai no tradutor simples pra não quebrar nada.
        return TradutorSimples().traduzir(emocao, confianca)


def obter_tradutor() -> TradutorDeHumor:
    """Fábrica: troque MOTOR_DE_TRADUCAO=ia no .env quando o TradutorComIA
    estiver implementado — nenhuma outra linha do projeto precisa mudar."""
    if settings.MOTOR_DE_TRADUCAO == 'ia':
        return TradutorComIA()
    return TradutorSimples()
