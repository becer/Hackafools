"""Cliente HTTP responsável por conversar com o servidor de inferência que
roda dentro do notebook do Google Colab (exposto publicamente via ngrok).
"""
import requests
from django.conf import settings

from translator.models import ConfiguracaoColab


class ColabIndisponivelError(Exception):
    """Levantado quando não dá pra falar com o Colab ou ele erra."""


def obter_url_colab() -> str:
    """Pega a URL mais recente registrada pelo notebook. Se nenhuma foi
    registrada ainda, cai no COLAB_API_URL fixo do .env como reserva."""
    config = ConfiguracaoColab.objects.first()
    if config:
        return config.url_atual.rstrip('/')
    if settings.COLAB_API_URL:
        return settings.COLAB_API_URL.rstrip('/')
    raise ColabIndisponivelError(
        'Nenhuma URL do Colab configurada ainda. Rode o notebook (ele se '
        'registra sozinho em /api/colab/registrar/) ou defina COLAB_API_URL '
        'no .env manualmente.'
    )


def analisar_audio(caminho_do_arquivo: str) -> dict:
    """Envia o áudio pro modelo rodando no Colab e devolve algo como
    {"emocao": "brava", "confianca": 0.87}."""
    url_base = obter_url_colab()

    try:
        with open(caminho_do_arquivo, 'rb') as arquivo:
            resposta = requests.post(
                f'{url_base}/predict',
                files={'audio': arquivo},
                headers={'Authorization': f'Bearer {settings.COLAB_API_KEY}'},
                timeout=settings.COLAB_TIMEOUT_SEGUNDOS,
            )
    except requests.exceptions.RequestException as exc:
        raise ColabIndisponivelError(
            f'Não consegui falar com o Colab (ele pode ter reiniciado, o que '
            f'muda a URL do ngrok): {exc}'
        ) from exc

    if resposta.status_code != 200:
        raise ColabIndisponivelError(
            f'Colab respondeu com erro {resposta.status_code}: {resposta.text[:300]}'
        )

    dados = resposta.json()
    if 'emocao' not in dados:
        raise ColabIndisponivelError(f'Resposta em formato inesperado do Colab: {dados}')

    return dados
