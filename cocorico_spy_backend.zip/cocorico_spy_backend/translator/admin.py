from django.contrib import admin

from .models import ConfiguracaoColab, Interceptacao


@admin.register(Interceptacao)
class InterceptacaoAdmin(admin.ModelAdmin):
    list_display = ('id', 'status', 'emocao_detectada', 'confianca', 'criado_em')
    list_filter = ('status', 'emocao_detectada')
    readonly_fields = ('criado_em', 'atualizado_em')


@admin.register(ConfiguracaoColab)
class ConfiguracaoColabAdmin(admin.ModelAdmin):
    list_display = ('url_atual', 'atualizado_em')
    readonly_fields = ('atualizado_em',)
