from django.conf import settings
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import ConfiguracaoColab, Interceptacao
from .serializers import InterceptacaoSerializer, InterceptacaoUploadSerializer
from .services.colab_client import ColabIndisponivelError, analisar_audio
from .services.traducao import obter_tradutor


class InterceptacaoUploadView(APIView):
    """POST /api/interceptacoes/

    Recebe um áudio (arquivo de upload OU blob gravado pelo microfone no
    navegador), manda pro Colab analisar e devolve a emoção detectada + a
    frase já traduzida.
    """

    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        upload_serializer = InterceptacaoUploadSerializer(data=request.data)
        upload_serializer.is_valid(raise_exception=True)
        interceptacao = upload_serializer.save(status=Interceptacao.Status.PROCESSANDO)

        try:
            resultado = analisar_audio(interceptacao.audio.path)
        except ColabIndisponivelError as exc:
            interceptacao.status = Interceptacao.Status.ERRO
            interceptacao.erro = str(exc)
            interceptacao.save()
            return Response(
                InterceptacaoSerializer(interceptacao).data,
                status=status.HTTP_502_BAD_GATEWAY,
            )

        emocao = resultado['emocao']
        confianca = resultado.get('confianca')

        tradutor = obter_tradutor()
        frase = tradutor.traduzir(emocao, confianca)

        interceptacao.emocao_detectada = emocao
        interceptacao.confianca = confianca
        interceptacao.frase_traduzida = frase
        interceptacao.status = Interceptacao.Status.CONCLUIDO
        interceptacao.save()

        return Response(InterceptacaoSerializer(interceptacao).data, status=status.HTTP_201_CREATED)


class InterceptacaoDetalheView(APIView):
    """GET /api/interceptacoes/<id>/

    Consulta um resultado já processado. Fica pronto pra quando o
    processamento virar assíncrono (ex: com Celery) e o front-end precisar
    fazer polling em vez de esperar a resposta do POST.
    """

    def get(self, request, pk):
        interceptacao = get_object_or_404(Interceptacao, pk=pk)
        return Response(InterceptacaoSerializer(interceptacao).data)


class RegistrarColabView(APIView):
    """POST /api/colab/registrar/

    O próprio notebook chama esse endpoint assim que sobe o túnel ngrok,
    avisando qual é a URL pública atual. Isso evita ter que copiar e colar
    a URL manualmente toda vez que o Colab reinicia (o que muda a URL).
    """

    def post(self, request):
        chave_enviada = request.data.get('chave')
        if chave_enviada != settings.COLAB_API_KEY:
            return Response({'erro': 'chave inválida'}, status=status.HTTP_401_UNAUTHORIZED)

        url = request.data.get('url')
        if not url:
            return Response({'erro': 'campo "url" é obrigatório'}, status=status.HTTP_400_BAD_REQUEST)

        ConfiguracaoColab.objects.create(url_atual=url)
        return Response({'ok': True, 'url_registrada': url})
