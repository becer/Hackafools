from django.db import models


class Interceptacao(models.Model):
    """Cada áudio enviado (upload ou gravado no site) vira um registro
    destes, guardando o resultado do modelo e a frase traduzida."""

    class Status(models.TextChoices):
        PENDENTE = 'pendente', 'Pendente'
        PROCESSANDO = 'processando', 'Processando'
        CONCLUIDO = 'concluido', 'Concluído'
        ERRO = 'erro', 'Erro'

    audio = models.FileField(upload_to='audios/%Y/%m/%d/')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDENTE)

    emocao_detectada = models.CharField(max_length=50, blank=True, null=True)
    confianca = models.FloatField(blank=True, null=True)
    frase_traduzida = models.TextField(blank=True, null=True)
    erro = models.TextField(blank=True, null=True)

    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-criado_em']

    def __str__(self):
        return f'Interceptacao #{self.pk} ({self.status})'


class ConfiguracaoColab(models.Model):
    """Guarda a URL pública (ngrok) mais recente do servidor de inferência
    rodando no Colab. O próprio notebook chama /api/colab/registrar/ toda
    vez que sobe, então você nunca precisa colar a URL na mão."""

    url_atual = models.URLField()
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-atualizado_em']

    def __str__(self):
        return f'Colab em {self.url_atual} (atualizado em {self.atualizado_em:%d/%m %H:%M})'
