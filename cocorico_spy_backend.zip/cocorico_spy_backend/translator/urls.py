from django.urls import path

from .views import InterceptacaoDetalheView, InterceptacaoUploadView, RegistrarColabView

urlpatterns = [
    path('interceptacoes/', InterceptacaoUploadView.as_view(), name='interceptacao-upload'),
    path('interceptacoes/<int:pk>/', InterceptacaoDetalheView.as_view(), name='interceptacao-detalhe'),
    path('colab/registrar/', RegistrarColabView.as_view(), name='colab-registrar'),
]
