"""
COLE ISTO EM UMA CÉLULA DO GOOGLE COLAB.

Antes, em outra célula, instale as dependências:

    !pip install fastapi uvicorn pyngrok python-multipart nest_asyncio requests
    !pip install librosa scikit-learn pydub

E suba seus arquivos .wav de treino (um ou mais por emoção) pro Colab
(barra lateral > Arquivos, ou monte o Google Drive).

Este script:
  1) extrai as mesmas características de áudio do seu snippet original
     (MFCCs + centroide espectral);
  2) treina um RandomForest com várias emoções (não só brava/calma);
  3) sobe uma API FastAPI com o endpoint POST /predict, que é exatamente
     o que translator/services/colab_client.py do Django chama;
  4) expõe essa API publicamente via ngrok e avisa o Django automaticamente
     qual é a URL atual, pra você não precisar copiar/colar toda vez que
     o Colab reiniciar.
"""

import os
import shutil
import tempfile

import librosa
import nest_asyncio
import numpy as np
import requests
import uvicorn
from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from pyngrok import ngrok
from sklearn.ensemble import RandomForestClassifier

# ------------------------------------------------------------------
# 1) Extração de características — igual ao seu snippet original
# ------------------------------------------------------------------


def extrair_caracteristicas(caminho_pro_arquivo: str) -> np.ndarray:
    y, sr = librosa.load(caminho_pro_arquivo, sr=None)

    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    mfccs_medio = np.mean(mfccs.T, axis=0)

    centroide = librosa.feature.spectral_centroid(y=y, sr=sr)
    centroide_medio = np.mean(centroide)

    return np.hstack((mfccs_medio, centroide_medio))


# ------------------------------------------------------------------
# 2) Treino — agora com mais estados de humor.
#
#    Troque os caminhos pelos seus arquivos reais. Pode (e deve) colocar
#    vários arquivos por emoção — quanto mais exemplos, melhor o modelo.
#    IMPORTANTE: as chaves aqui embaixo (brava, calma, feliz...) precisam
#    bater com as chaves do FRASES em translator/services/traducao.py
#    no lado do Django, senão a tradução cai no texto genérico.
# ------------------------------------------------------------------

ARQUIVOS_DE_TREINO = {
    'brava': ['galinha_brava.wav'],
    'calma': ['galinha_calma.wav'],
    'feliz': ['galinha_feliz.wav'],
    'triste': ['galinha_triste.wav'],
    'pergunta': ['galinha_pergunta.wav'],
    # 'medo': ['galinha_medo.wav'],
}

X_treino, y_treino = [], []
for emocao, arquivos in ARQUIVOS_DE_TREINO.items():
    for caminho in arquivos:
        if os.path.exists(caminho):
            X_treino.append(extrair_caracteristicas(caminho))
            y_treino.append(emocao)
        else:
            print(f'[aviso] arquivo não encontrado, pulando: {caminho}')

if len(set(y_treino)) < 2:
    raise RuntimeError(
        'Preciso de pelo menos 2 emoções com áudio de treino disponível '
        'antes de treinar o classificador.'
    )

classificador = RandomForestClassifier(n_estimators=200, random_state=42)
classificador.fit(X_treino, y_treino)
print(f'Modelo treinado com as emoções: {sorted(set(y_treino))}')

# ------------------------------------------------------------------
# 3) API que o Django vai chamar
# ------------------------------------------------------------------

# Precisa ser IGUAL ao COLAB_API_KEY do .env do Django.
CHAVE_SECRETA = os.getenv('COLAB_API_KEY', 'troque-essa-chave')
# URL pública do seu Django (em produção; localhost não funciona a partir
# do Colab, que roda em outra máquina). Pode deixar em branco e registrar
# a URL manualmente no admin do Django se preferir.
URL_DO_DJANGO = os.getenv('DJANGO_URL', '')

app = FastAPI(title='Cocorico Spy - Servidor de Inferência')


@app.post('/predict')
async def predict(audio: UploadFile = File(...), authorization: str = Header(None)):
    if authorization != f'Bearer {CHAVE_SECRETA}':
        raise HTTPException(status_code=401, detail='chave inválida')

    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
        shutil.copyfileobj(audio.file, tmp)
        caminho_temporario = tmp.name

    try:
        caracteristicas = extrair_caracteristicas(caminho_temporario)
        probabilidades = classificador.predict_proba([caracteristicas])[0]
        indice = int(np.argmax(probabilidades))
        emocao = classificador.classes_[indice]
        confianca = float(probabilidades[indice])
    finally:
        os.remove(caminho_temporario)

    return {'emocao': emocao, 'confianca': confianca}


@app.get('/saude')
async def saude():
    return {'status': 'ok', 'emocoes_conhecidas': sorted(set(y_treino))}


# ------------------------------------------------------------------
# 4) Sobe o túnel ngrok e avisa o Django qual é a URL pública atual
# ------------------------------------------------------------------

nest_asyncio.apply()

tunel = ngrok.connect(8000)
url_publica = tunel.public_url
print(f'Servidor de inferência disponível em: {url_publica}')
print(f'Endpoint de predição: {url_publica}/predict')

if URL_DO_DJANGO:
    try:
        requests.post(
            f'{URL_DO_DJANGO}/api/colab/registrar/',
            json={'url': url_publica, 'chave': CHAVE_SECRETA},
            timeout=5,
        )
        print('Django avisado com sucesso sobre a nova URL.')
    except requests.exceptions.RequestException as exc:
        print(f'Não consegui avisar o Django automaticamente ({exc}).')
        print('Copie a URL acima e defina COLAB_API_URL no .env do Django, ou')
        print('cadastre-a manualmente em /admin/translator/configuracaocolab/.')
else:
    print('DJANGO_URL não definida — copie a URL acima e configure '
          'COLAB_API_URL no .env do Django, ou cadastre em /admin/.')

uvicorn.run(app, host='0.0.0.0', port=8000)
